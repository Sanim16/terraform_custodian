# Generated via tools/dev/devpkg.py
version = "0.9.47"
